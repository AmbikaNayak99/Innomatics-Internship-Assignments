class Solution:
    def sortByBits(self, arr: List[int]) -> List[int]:
        def pop(n):
            output=0
            while n:
                n&=(n-1)
                output+=1
            return output 
        arr.sort(key=lambda x: (pop(x),x))
        return arr