class Solution:
    def singleNumber(self, nums: List[int]) -> List[int]:
        a=set(nums)
        b=a.copy()
        for i in nums:
            if i in a:
                a.remove(i)
                continue
            if i in b:
                b.remove(i)
        return list(b)