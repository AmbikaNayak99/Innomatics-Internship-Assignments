import streamlit as st 
import pandas as pd
import numpy as np
path=r"C:\Users\AMBIKA\Desktop\Internship\Pages\Open_Pub.csv"
st.title("Pubs Location In Maps")
df=pd.read_csv(path)
#st.dataframe(df.head())
location=df[["latitude","longitude"]]
#st.write(location)
st.map(location)