x=int(input())
for i in range(x):
    a=input()
    a1=set(input().split())
    b=int(input())
    b1=set(input().split())
    print(a1.issubset(b1))