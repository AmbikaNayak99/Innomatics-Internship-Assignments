list_marks=[]
marks=[]
    
if __name__ == '__main__':
    for _ in range(int(input())):
        name = input()
        score = float(input())
        list_marks+=[[name,score]]
        marks+=[score]
    a=sorted(set(marks))[1]
    for n, s in sorted(list_marks):
        if s==a:
            print(n)