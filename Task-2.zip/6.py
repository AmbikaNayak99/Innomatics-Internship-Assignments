def average(array):
    # your code goes here
    solution= sum(set(array))/len(set(array))
    return solution
if __name__ == '__main__':
    n = int(input())
    arr = list(map(int, input().split()))
    result = average(arr)
    print(result)