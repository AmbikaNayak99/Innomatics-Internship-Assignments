n=int(input())
l=set(map(int, input().split()))
r=int(input())
for i in range(r):
    sr,num = input().split()
    l2=set(map(int, input().split()))
    eval("l.{0}({1})".format(sr,l2))
print(sum(l))