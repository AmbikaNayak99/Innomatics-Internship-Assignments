x=set(input().split())
print(all(x>set(input().split()) for i in range(int(input()))))